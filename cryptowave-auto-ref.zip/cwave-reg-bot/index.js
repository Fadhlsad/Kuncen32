/**
 * CWave Registration Bot - CLI Entry Point
 * Usage: node index.js [command]
 * 
 * Commands:
 *   (default)         Run all: generate + register + tasks
 *   --generate        Generate new accounts only
 *   --register        Register unregistered accounts
 *   --tasks           Run tasks for registered accounts
 *   --check-accounts  Show account statistics
 *   --clear-data      Clear all data
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PATHS = {
    accountsTxt: path.join(__dirname, 'accounts.txt'),
    log: path.join(__dirname, 'logs', 'process.log'),
    data: path.join(__dirname, 'data', 'data.json'),
    env: path.join(__dirname, '.env'),
};

async function clearData() {
    if (fs.existsSync(PATHS.data)) {
        fs.writeFileSync(PATHS.data, '{}');
        console.log('✓ data.json cleared');
    }
    if (fs.existsSync(PATHS.accountsTxt)) {
        fs.writeFileSync(PATHS.accountsTxt, '');
        console.log('✓ accounts.txt cleared');
    }
    console.log('All data has been reset');
}

async function checkConfig() {
    console.log('\n📋 Configuration Check\n');

    if (fs.existsSync(PATHS.env)) {
        const envContent = fs.readFileSync(PATHS.env, 'utf-8');
        const emailCount = (envContent.match(/^EMAIL_\d+=/gm) || []).length;
        console.log(`✓ .env found with ${emailCount} base email(s)`);
    } else {
        console.log('✗ .env not found (create from .env.example)');
    }

    if (fs.existsSync(PATHS.data)) {
        try {
            const data = JSON.parse(fs.readFileSync(PATHS.data, 'utf-8'));
            const count = Object.keys(data).length;
            const registered = Object.values(data).filter(a => a.registered).length;
            console.log(`✓ data.json: ${count} accounts (${registered} registered)`);
        } catch {
            console.log('✗ data.json is corrupted');
        }
    } else {
        console.log('○ data.json not found (will be created on first run)');
    }

    console.log('');
}

async function runGenerate() {
    const { generateAccounts } = await import('./src/app.js');
    const { createLogger } = await import('./src/utils/logger.js');
    await generateAccounts(createLogger());
}

async function runRegister() {
    const { registerAccounts } = await import('./src/app.js');
    const { createLogger } = await import('./src/utils/logger.js');
    await registerAccounts(createLogger());
}

async function runTasksCommand() {
    const { runTasks } = await import('./src/app.js');
    const { createLogger } = await import('./src/utils/logger.js');
    await runTasks(createLogger());
}

async function runAll() {
    const { run } = await import('./src/app.js');
    await run();
}

async function checkAccounts() {
    const { showAccountStats } = await import('./src/app.js');
    const { createLogger } = await import('./src/utils/logger.js');
    showAccountStats(createLogger());
}

// Parse CLI arguments
const args = process.argv.slice(2);
const command = args[0];

switch (command) {
    case '--generate':
        await runGenerate();
        break;
    case '--register':
        await runRegister();
        break;
    case '--tasks':
        await runTasksCommand();
        break;
    case '--check-accounts':
    case '--show-accounts':
        await checkAccounts();
        break;
    case '--check-config':
        await checkConfig();
        break;
    case '--clear-data':
        await clearData();
        break;
    default:
        await runAll();
}
