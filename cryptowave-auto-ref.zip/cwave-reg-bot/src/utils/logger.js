import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const LOG_FILE = path.join(__dirname, '../../logs/process.log');

// Ensure logs directory exists
const logsDir = path.dirname(LOG_FILE);
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
}

/**
 * Create a logger instance
 */
export function createLogger(prefix = '') {
    const formatMessage = (level, msg) => {
        const timestamp = new Date().toISOString();
        const prefixStr = prefix ? `[${prefix}] ` : '';
        return `[${timestamp}] [${level}] ${prefixStr}${msg}`;
    };

    const log = (level, msg) => {
        const formatted = formatMessage(level, msg);
        console.log(formatted);
        try {
            fs.appendFileSync(LOG_FILE, formatted + '\n');
        } catch (e) {
            // Ignore file write errors
        }
    };

    return {
        info: (msg) => log('INFO', `ℹ️ ${msg}`),
        success: (msg) => log('DONE', `✔️ ${msg}`),
        warn: (msg) => log('WARN', `⚠️ ${msg}`),
        error: (msg) => log('FAIL', `❌ ${msg}`),
        debug: (msg) => log('INFO', `⏳ ${msg}`),
    };
}

export default createLogger;
