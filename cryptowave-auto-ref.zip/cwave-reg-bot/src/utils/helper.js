import { randomBytes } from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import UserAgent from 'user-agents';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.join(__dirname, '../..');
const DATA_DIR = path.join(ROOT_DIR, 'data');
const DATA_FILE = path.join(DATA_DIR, 'data.json');
const ACCOUNTS_TXT = path.join(ROOT_DIR, 'accounts.txt');

// User Agent Generator - Desktop Chrome only
const uaGenerator = new UserAgent({
    deviceCategory: 'desktop',
    platform: 'Win32',
});

/**
 * Generate a random Chrome user agent
 * @returns {string} User agent string
 */
export function generateUserAgent() {
    const ua = uaGenerator();
    if (ua.toString().includes('Chrome')) {
        return ua.toString();
    }
    return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36';
}


// Username Generation


const ADJECTIVES = [
    'Cool', 'Super', 'Hyper', 'Mega', 'Ultra', 'Cyber', 'Neon', 'Tech', 'Crypto', 'Meta', 'Smart', 'Clean',
    'Fast', 'Swift', 'Bright', 'Bold', 'Epic', 'Prime', 'Elite', 'Pro', 'Quantum', 'Atomic', 'Digital',
    'Virtual', 'Infinite', 'Stellar', 'Mystic', 'Phantom', 'Rogue', 'Lucky', 'Turbo', 'Apex', 'Ghost',
    'Liquid', 'Shadow', 'Token', 'Block', 'Chain', 'Mint', 'Hash', 'Byte', 'DeFi', 'Moon', 'Lunar',
    'Orbit', 'Rocket', 'Genesis', 'Protocol', 'Node', 'Pixel', 'Blocky', 'Minted', 'Airdrop', 'Swap',
    'Layer2', 'Metaverse', 'Neural', 'Staked', 'Unlocked', 'Dynamic', 'Boosted', 'Legendary'
];

const NOUNS = [
    'Trader', 'HODLer', 'Builder', 'Dev', 'Ninja', 'Guru', 'Whale', 'Shark', 'Bull', 'Bear', 'Falcon',
    'Eagle', 'Wolf', 'Lion', 'Tiger', 'Star', 'Moon', 'Sun', 'Orbit', 'Node', 'Miner', 'Ledger', 'Stake',
    'Vault', 'LP', 'Swap', 'Degen', 'Ape', 'Pixel', 'Gamer', 'Boss', 'Guild', 'DAO', 'Rocket', 'Coin',
    'Hero', 'Fork', 'Airdrop', 'Mint', 'Burn', 'Layer', 'Validator', 'Gem', 'Avatar', 'Quest', 'Arena',
    'Champion', 'Legend', 'Epic', 'Rare', 'Mystic', 'Orb', 'Crystal', 'Satoshi', 'NodeRunner', 'Bit',
    'Hash', 'Cipher', 'Coiner', 'Staker', 'MinerBot', 'DegenLord', 'SwapMaster', 'NFTHunter', 'PixelWarrior'
];

/**
 * Generate a random display name
 */
export function generateDisplayName() {
    const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
    const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
    const num = Math.floor(Math.random() * 1000);
    return `${adj}${noun}${num}`;
}


// Email Dot Variation Generator


export function generateDotVariations(email) {
    const [localPart, domain] = email.split('@');
    if (!localPart || !domain || localPart.length < 2) return [email];

    const variations = new Set();
    const chars = localPart.split('');
    const positions = chars.length - 1;
    const totalCombinations = Math.pow(2, positions);

    for (let mask = 0; mask < totalCombinations; mask++) {
        let result = chars[0];
        for (let i = 0; i < positions; i++) {
            if (mask & (1 << i)) {
                result += '.';
            }
            result += chars[i + 1];
        }
        if (result !== localPart && !result.includes('..')) {
            variations.add(`${result}@${domain}`);
        }
    }

    return Array.from(variations);
}

export function getRandomVariations(variations, min = 1, max = 20) {
    const count = Math.floor(Math.random() * (max - min + 1)) + min;
    const shuffled = [...variations].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, Math.min(count, shuffled.length));
}


// Password & UUID Generation


export function generateRandomPassword() {
    const length = 12 + Math.floor(Math.random() * 5);
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%';
    const bytes = randomBytes(length);
    let password = '';
    for (let i = 0; i < length; i++) {
        password += charset[bytes[i] % charset.length];
    }
    return password;
}

export function generateUUID() {
    const bytes = randomBytes(16);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;

    const hex = bytes.toString('hex');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}


// Delay Utilities


export function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Random delay between min and max milliseconds
 */
export function randomDelay(minMs, maxMs) {
    const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
    return sleep(delay);
}

export function getRandomItem(array) {
    if (!array || array.length === 0) return null;
    return array[Math.floor(Math.random() * array.length)];
}

export function normalizeProxy(proxy) {
    const schemes = ['http://', 'https://', 'socks4://', 'socks5://'];
    return schemes.some(s => proxy.startsWith(s)) ? proxy : `http://${proxy}`;
}


// Data Storage (data.json)


function ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }
}

export function loadAccounts() {
    ensureDataDir();
    if (!fs.existsSync(DATA_FILE)) {
        return {};
    }
    try {
        const data = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

export function saveAccounts(accounts) {
    ensureDataDir();
    fs.writeFileSync(DATA_FILE, JSON.stringify(accounts, null, 2));
}

export function getAccountData(email) {
    const accounts = loadAccounts();
    return accounts[email.toLowerCase()] || null;
}

export function updateAccountData(email, data) {
    const accounts = loadAccounts();
    const key = email.toLowerCase();

    accounts[key] = {
        ...accounts[key],
        ...data,
        updatedAt: new Date().toISOString(),
    };

    saveAccounts(accounts);
    return accounts[key];
}

export function saveAccount(email, password) {
    const accounts = loadAccounts();

    if (accounts[email.toLowerCase()]) {
        return false;
    }

    accounts[email.toLowerCase()] = {
        email,
        password,
        createdAt: new Date().toISOString(),
        registered: false,
    };

    saveAccounts(accounts);
    fs.appendFileSync(ACCOUNTS_TXT, `${email}:${password}\n`);

    return true;
}

export function getAccountsByStatus(registered = false) {
    const accounts = loadAccounts();
    return Object.values(accounts).filter(a => a.registered === registered);
}

export function getAccountCount() {
    const accounts = loadAccounts();
    return Object.keys(accounts).length;
}


// ProxyPool - Concurrent Proxy Management


export class ProxyPool {
    constructor(proxies) {
        this.proxies = proxies.map((url) => ({
            url: normalizeProxy(url),
            busy: false,
            usageCount: 0,
            blockCount: 0,
            blocked: false,
        }));
        this.waitQueue = [];
        this.noProxyMode = proxies.length === 0;
        this.MAX_BLOCK_COUNT = 10;

        this.noProxyBusy = false;
        this.noProxyWaitQueue = [];
    }

    async acquire() {
        if (this.noProxyMode) {
            if (!this.noProxyBusy) {
                this.noProxyBusy = true;
                return null;
            }
            return new Promise((resolve) => {
                this.noProxyWaitQueue.push(() => {
                    this.noProxyBusy = true;
                    resolve(null);
                });
            });
        }

        const idle = this.proxies.find((p) => !p.busy && !p.blocked);
        if (idle) {
            idle.busy = true;
            idle.usageCount++;
            return idle.url;
        }

        const allBlocked = this.proxies.every((p) => p.blocked);
        if (allBlocked) {
            throw new Error('All proxies are blocked');
        }

        return new Promise((resolve) => {
            this.waitQueue.push(resolve);
        });
    }

    release(proxyUrl) {
        if (this.noProxyMode) {
            if (this.noProxyWaitQueue.length > 0) {
                const nextCallback = this.noProxyWaitQueue.shift();
                nextCallback();
            } else {
                this.noProxyBusy = false;
            }
            return;
        }

        if (proxyUrl === null) return;

        const proxy = this.proxies.find((p) => p.url === proxyUrl);
        if (!proxy) return;

        if (!proxy.blocked && this.waitQueue.length > 0) {
            const nextResolve = this.waitQueue.shift();
            proxy.usageCount++;
            nextResolve(proxy.url);
        } else {
            proxy.busy = false;
        }
    }

    markBlocked(proxyUrl) {
        if (this.noProxyMode || proxyUrl === null) return false;
        const proxy = this.proxies.find((p) => p.url === proxyUrl);
        if (!proxy) return false;

        proxy.blockCount++;
        if (proxy.blockCount >= this.MAX_BLOCK_COUNT) {
            proxy.blocked = true;
            proxy.busy = false;
            return true;
        }
        return false;
    }

    markSuccess(proxyUrl) {
        if (this.noProxyMode || proxyUrl === null) return;
        const proxy = this.proxies.find((p) => p.url === proxyUrl);
        if (proxy && !proxy.blocked) {
            proxy.blockCount = 0;
        }
    }

    getConcurrency() {
        if (this.noProxyMode) return 1;
        const available = this.proxies.filter((p) => !p.blocked).length;
        return available > 0 ? available : 1;
    }

    getStats() {
        if (this.noProxyMode) {
            return { total: 0, active: 0, idle: 0, blocked: 0, waiting: 0 };
        }

        const active = this.proxies.filter((p) => p.busy && !p.blocked).length;
        const blocked = this.proxies.filter((p) => p.blocked).length;
        return {
            total: this.proxies.length,
            active,
            idle: this.proxies.length - active - blocked,
            blocked,
            waiting: this.waitQueue.length,
        };
    }
}
