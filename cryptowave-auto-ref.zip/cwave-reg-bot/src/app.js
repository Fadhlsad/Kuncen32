/**
 * CWave Registration Bot - Main Application
 */

import 'dotenv/config';
import { readFileSync, existsSync } from 'fs';
import { createLogger } from './utils/logger.js';
import { registerAccount } from './services/auth.js';
import { completeTasks } from './services/tasks.js';
import {
    generateDotVariations,
    getRandomVariations,
    generateRandomPassword,
    loadAccounts,
    saveAccount,
    getAccountCount,
    getAccountsByStatus,
    ProxyPool,
    sleep,
    randomDelay
} from './utils/helper.js';

/**
 * Load base emails from environment variables
 */
function loadBaseEmails() {
    const emails = [];
    let i = 1;
    while (process.env[`EMAIL_${i}`]) {
        const email = process.env[`EMAIL_${i}`].trim();
        if (email && email.includes('@')) {
            emails.push(email);
        }
        i++;
    }
    return emails;
}

/**
 * Load proxies from proxies.txt
 */
function loadProxies() {
    const proxyFile = './proxies.txt';
    if (!existsSync(proxyFile)) return [];
    const content = readFileSync(proxyFile, 'utf-8');
    return content.split('\n').map(line => line.trim()).filter(line => line && !line.startsWith('#'));
}

/**
 * Generate accounts from base emails
 */
export async function generateAccounts(logger) {
    const baseEmails = loadBaseEmails();

    if (baseEmails.length === 0) {
        logger.error('No base emails found. Add EMAIL_1, EMAIL_2, etc. to your .env file');
        return { success: false, error: 'no_emails' };
    }

    logger.info(`Loaded ${baseEmails.length} base email(s)`);

    const existingAccounts = loadAccounts();
    const existingEmails = new Set(Object.keys(existingAccounts).map(e => e.toLowerCase()));
    logger.info(`Existing accounts: ${existingEmails.size}`);

    let totalGenerated = 0;

    for (const baseEmail of baseEmails) {
        logger.info(`Processing: ${baseEmail}`);

        const allVariations = generateDotVariations(baseEmail);
        logger.info(`  Total variations: ${allVariations.length}`);

        const newVariations = allVariations.filter(v => !existingEmails.has(v.toLowerCase()));
        logger.info(`  Available new: ${newVariations.length}`);

        if (newVariations.length === 0) {
            logger.warn(`  No new variations for ${baseEmail}`);
            continue;
        }

        const selectedVariations = getRandomVariations(newVariations, 1, 20);
        logger.info(`  Selected: ${selectedVariations.length}`);

        for (const email of selectedVariations) {
            const password = generateRandomPassword();
            const saved = saveAccount(email, password);

            if (saved) {
                logger.success(`Created: ${email}`);
                existingEmails.add(email.toLowerCase());
                totalGenerated++;
            }
        }
    }

    logger.info('═══ GENERATION COMPLETE ═══');
    logger.info(`New accounts: ${totalGenerated}`);
    logger.info(`Total accounts: ${getAccountCount()}`);

    return { success: true, generated: totalGenerated, total: getAccountCount() };
}

/**
 * Register all unregistered accounts
 */
export async function registerAccounts(logger) {
    const proxies = loadProxies();
    const proxyPool = new ProxyPool(proxies);

    const unregistered = getAccountsByStatus(false);

    if (unregistered.length === 0) {
        logger.info('No unregistered accounts found');
        return { success: true, registered: 0 };
    }

    logger.info(`Found ${unregistered.length} unregistered account(s)`);
    logger.info(`Proxies: ${proxies.length}, Concurrency: ${proxyPool.getConcurrency()}`);

    let successCount = 0;
    let failCount = 0;

    const processAccount = async (account) => {
        let proxy = null;
        try {
            proxy = await proxyPool.acquire();

            const result = await registerAccount(account, proxy, logger);

            if (result.success) {
                proxyPool.markSuccess(proxy);
                successCount++;
            } else {
                failCount++;
            }

            // Random delay 5-15s between accounts
            await randomDelay(5000, 15000);

        } catch (error) {
            logger.error(`[${account.email}] Error: ${error.message?.slice(0, 80)}`);
            if (proxy) proxyPool.markBlocked(proxy);
            failCount++;
        } finally {
            if (proxy !== null || proxyPool.noProxyMode) {
                proxyPool.release(proxy);
            }
        }
    };

    // Process all accounts concurrently (limited by proxy pool)
    const promises = unregistered.map(account => processAccount(account));
    await Promise.all(promises);

    logger.info('═══ REGISTRATION COMPLETE ═══');
    logger.info(`Success: ${successCount}, Failed: ${failCount}`);

    return { success: true, registered: successCount, failed: failCount };
}

/**
 * Run tasks for all registered accounts
 */
export async function runTasks(logger) {
    const proxies = loadProxies();
    const proxyPool = new ProxyPool(proxies);

    const registered = getAccountsByStatus(true);

    if (registered.length === 0) {
        logger.info('No registered accounts found');
        return { success: true, completed: 0 };
    }

    logger.info(`Found ${registered.length} registered account(s)`);

    let totalCompleted = 0;

    const processAccount = async (account) => {
        let proxy = null;
        try {
            proxy = await proxyPool.acquire();

            const result = await completeTasks(account, proxy, logger);

            if (result.success) {
                proxyPool.markSuccess(proxy);
                totalCompleted += result.completed || 0;
            }

            // Random delay 5-15s between accounts
            await randomDelay(5000, 15000);

        } catch (error) {
            logger.error(`[${account.email}] Error: ${error.message?.slice(0, 80)}`);
            if (proxy) proxyPool.markBlocked(proxy);
        } finally {
            if (proxy !== null || proxyPool.noProxyMode) {
                proxyPool.release(proxy);
            }
        }
    };

    const promises = registered.map(account => processAccount(account));
    await Promise.all(promises);

    logger.info('═══ TASKS COMPLETE ═══');
    logger.info(`Total tasks completed: ${totalCompleted}`);

    return { success: true, completed: totalCompleted };
}

/**
 * Show account statistics
 */
export function showAccountStats(logger) {
    const accounts = loadAccounts();
    const count = Object.keys(accounts).length;

    logger.info('═══ ACCOUNT STATISTICS ═══');
    logger.info(`Total accounts: ${count}`);

    if (count > 0) {
        const registered = Object.values(accounts).filter(a => a.registered).length;
        const pending = count - registered;
        const withBalance = Object.values(accounts).filter(a => a.earnBalance > 0);
        const totalEarn = withBalance.reduce((sum, a) => sum + (a.earnBalance || 0), 0);

        logger.info(`Registered: ${registered}`);
        logger.info(`Pending: ${pending}`);
        if (withBalance.length > 0) {
            logger.info(`Total EARN balance: ${totalEarn.toFixed(2)}`);
        }
    }
}

/**
 * Default run (generate + register + tasks)
 */
export async function run() {
    const logger = createLogger();

    logger.info('Starting CWave Bot...');

    await generateAccounts(logger);
    await registerAccounts(logger);
    await runTasks(logger);
}
