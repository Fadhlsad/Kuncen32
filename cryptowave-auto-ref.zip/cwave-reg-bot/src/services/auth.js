/**
 * CWave Registration Bot - Authentication Service
 */

import { createApiClient } from '../core/api.js';
import { REF_CODES } from '../../config.js';
import { generateUUID, generateDisplayName, generateUserAgent, getRandomItem, updateAccountData, randomDelay, getAccountData } from '../utils/helper.js';

const MAX_RETRIES = 50;

/**
 * Check if error is retryable
 */
function isRetryableError(error) {
    const msg = (error?.message || '').toLowerCase();
    return msg.includes('timeout') ||
        msg.includes('econnreset') ||
        msg.includes('econnrefused') ||
        msg.includes('etimedout') ||
        msg.includes('socket') ||
        msg.includes('network') ||
        msg.includes('proxy') ||
        msg.includes('502') ||
        msg.includes('503') ||
        msg.includes('504') ||
        msg.includes('429');
}

/**
 * Login to get fresh tokens with retry logic
 * @param {object} account - Account { email, password }
 * @param {string|null} proxyUrl - Proxy URL
 * @param {object} logger - Logger instance
 * @returns {Promise<object>} Login result with tokens
 */
export async function loginAccount(account, proxyUrl, logger) {
    const { email, password } = account;
    const shortEmail = email.length > 20 ? `${email.slice(0, 17)}...` : email;

    // Get or generate user agent
    const existingData = getAccountData(email);
    const userAgent = existingData?.userAgent || generateUserAgent();

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            const api = createApiClient(proxyUrl, userAgent);

            if (attempt === 1) {
                logger.info(`[${shortEmail}] Logging in...`);
            } else {
                logger.info(`[${shortEmail}] Login retry ${attempt}/${MAX_RETRIES}`);
            }

            const loginResult = await api.login(email, password);

            if (!loginResult || !loginResult.access_token) {
                throw new Error('Login failed: no access token returned');
            }

            logger.debug(`[${shortEmail}] Logged in successfully`);

            // Update stored tokens
            updateAccountData(email, {
                userAgent,
                accessToken: loginResult.access_token,
                refreshToken: loginResult.refresh_token,
                tokenExpiresAt: loginResult.expires_at,
                userId: loginResult.user.id,
            });

            return {
                success: true,
                email,
                accessToken: loginResult.access_token,
                userId: loginResult.user.id,
            };

        } catch (error) {
            const errorMsg = (error?.message || 'Unknown error').replace(/\n/g, ' ');

            if (isRetryableError(error) && attempt < MAX_RETRIES) {
                logger.warn(`[${shortEmail}] Login attempt ${attempt} failed: ${errorMsg} - Retrying...`);
                await randomDelay(3000, 5000);
                continue;
            }

            logger.error(`[${shortEmail}] Login failed: ${errorMsg}`);
            return {
                success: false,
                email,
                error: errorMsg,
            };
        }
    }

    return { success: false, email, error: 'Max retries exceeded' };
}

/**
 * Register a single account with retry logic
 * @param {object} account - Account from data.json { email, password }
 * @param {string|null} proxyUrl - Proxy URL
 * @param {object} logger - Logger instance
 * @returns {Promise<object>} Registration result
 */
export async function registerAccount(account, proxyUrl, logger) {
    const { email, password } = account;
    const shortEmail = email.length > 20 ? `${email.slice(0, 17)}...` : email;

    let lastError = null;

    // Generate user agent for this account
    const userAgent = generateUserAgent();

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            const api = createApiClient(proxyUrl, userAgent);
            const sessionId = generateUUID();
            const refCode = getRandomItem(REF_CODES);
            const displayName = generateDisplayName();

            if (attempt === 1) {
                logger.info(`[${shortEmail}] Starting registration with ref: ${refCode}`);
            } else {
                logger.info(`[${shortEmail}] Retry ${attempt}/${MAX_RETRIES}`);
            }

            // Step 1: Send analytics
            await api.sendAnalytics(sessionId, refCode);
            logger.debug(`[${shortEmail}] Analytics sent`);
            await randomDelay(3000, 5000);

            // Step 2: Signup with Supabase
            const signupResult = await api.signup(email, password, displayName, refCode);

            if (!signupResult || !signupResult.access_token) {
                throw new Error('Signup failed: no access token returned');
            }

            logger.success(`[${shortEmail}] Registered successfully`);

            // Save registration data
            const registrationData = {
                registered: true,
                registeredAt: new Date().toISOString(),
                userId: signupResult.user.id,
                accessToken: signupResult.access_token,
                refreshToken: signupResult.refresh_token,
                tokenExpiresAt: signupResult.expires_at,
                displayName: signupResult.user.user_metadata.display_name,
                userAgent,
                usedRefCode: refCode,
                lastError: null,
            };

            updateAccountData(email, registrationData);

            return {
                success: true,
                email,
                userId: signupResult.user.id,
                displayName,
                refCode,
            };

        } catch (error) {
            lastError = error;
            const errorMsg = (error?.message || 'Unknown error').replace(/\n/g, ' ');

            // Check if error is retryable
            if (isRetryableError(error) && attempt < MAX_RETRIES) {
                logger.warn(`[${shortEmail}] Attempt ${attempt} failed: ${errorMsg} - Retrying...`);
                await randomDelay(3000, 5000);
                continue;
            }

            // Check if user is already registered - try to login instead
            if (errorMsg.toLowerCase().includes('already registered')) {
                logger.info(`[${shortEmail}] Already registered, attempting login...`);

                try {
                    const api = createApiClient(proxyUrl, userAgent);
                    const loginResult = await api.login(email, password);

                    if (loginResult?.access_token) {
                        logger.success(`[${shortEmail}] Login successful (already registered)`);

                        updateAccountData(email, {
                            registered: true,
                            registeredAt: new Date().toISOString(),
                            userId: loginResult.user.id,
                            accessToken: loginResult.access_token,
                            refreshToken: loginResult.refresh_token,
                            tokenExpiresAt: loginResult.expires_at,
                            userAgent,
                            lastError: null,
                        });

                        return {
                            success: true,
                            email,
                            userId: loginResult.user.id,
                            alreadyRegistered: true,
                        };
                    }
                } catch (loginError) {
                    logger.warn(`[${shortEmail}] Login also failed: ${loginError.message?.slice(0, 50)}`);
                }
            }

            // Non-retryable error or final attempt - show full error
            logger.error(`[${shortEmail}] Registration failed: ${errorMsg}`);

            // Mark as failed
            updateAccountData(email, {
                registered: false,
                lastError: errorMsg,
                lastAttempt: new Date().toISOString(),
            });

            return {
                success: false,
                email,
                error: errorMsg,
            };
        }
    }

    // Should not reach here, but just in case
    return {
        success: false,
        email,
        error: lastError?.message || 'Max retries exceeded',
    };
}

export default registerAccount;
