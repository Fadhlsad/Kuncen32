/**
 * CWave Registration Bot - Tasks Service
 */

import { createApiClient } from '../core/api.js';
import { loginAccount } from './auth.js';
import { updateAccountData, randomDelay } from '../utils/helper.js';

const MAX_RETRIES = 50;

/**
 * Calculate level based on XP
 */
function calculateLevel(xp) {
    if (xp >= 500) return 'Gold';
    if (xp >= 200) return 'Silver';
    if (xp >= 50) return 'Starter';
    return 'Bronze';
}

/**
 * Check if error is retryable
 */
function isRetryableError(error) {
    const msg = (error?.message || '').toLowerCase();
    return msg.includes('timeout') ||
        msg.includes('econnreset') ||
        msg.includes('econnrefused') ||
        msg.includes('etimedout') ||
        msg.includes('socket') ||
        msg.includes('network') ||
        msg.includes('proxy') ||
        msg.includes('502') ||
        msg.includes('503') ||
        msg.includes('504') ||
        msg.includes('429');
}

/**
 * Execute API call with retry
 */
async function withRetry(fn, context, logger, shortEmail) {
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            return await fn();
        } catch (error) {
            if (isRetryableError(error) && attempt < MAX_RETRIES) {
                logger.warn(`[${shortEmail}] ${context} retry ${attempt}/${MAX_RETRIES}`);
                await randomDelay(3000, 5000);
                continue;
            }
            throw error;
        }
    }
}

/**
 * Complete all available tasks for a registered account
 * Uses login to get fresh tokens before completing tasks
 * @param {object} account - Account from data.json { email, password, registered }
 * @param {string|null} proxyUrl - Proxy URL
 * @param {object} logger - Logger instance
 * @returns {Promise<object>} Tasks result
 */
export async function completeTasks(account, proxyUrl, logger) {
    const { email, password } = account;
    const shortEmail = email.length > 20 ? `${email.slice(0, 17)}...` : email;

    if (!account.registered) {
        return { success: false, reason: 'not_registered', skipped: true };
    }

    try {
        // Login to get fresh tokens using auth service
        const loginResult = await loginAccount(account, proxyUrl, logger);

        if (!loginResult.success) {
            return { success: false, reason: 'login_failed', error: loginResult.error };
        }

        const accessToken = loginResult.accessToken;
        const userId = loginResult.userId;
        // Use saved userAgent from account for consistent fingerprinting
        const userAgent = account.userAgent;
        const api = createApiClient(proxyUrl, userAgent);

        await randomDelay(3000, 5000);

        // Get current profile
        const profile = await withRetry(
            () => api.getProfile(accessToken, userId),
            'Get profile',
            logger,
            shortEmail
        );

        if (!profile) {
            logger.warn(`[${shortEmail}] Profile not found`);
            return { success: false, reason: 'no_profile' };
        }

        let earnBalance = parseFloat(profile.earn_balance) || 0;
        let xpBalance = parseInt(profile.xp_balance) || 0;

        logger.info(`[${shortEmail}] Current: ${earnBalance} EARN, ${xpBalance} XP`);
        await randomDelay(3000, 5000);

        // Get all active tasks
        const allTasks = await withRetry(
            () => api.getTasks(accessToken),
            'Get tasks',
            logger,
            shortEmail
        );
        await randomDelay(3000, 5000);

        // Get completed tasks
        const completedTaskIds = await withRetry(
            () => api.getCompletedTasks(accessToken, userId),
            'Get completed',
            logger,
            shortEmail
        );
        await randomDelay(3000, 5000);

        // Filter uncompleted tasks
        const pendingTasks = allTasks.filter(t => !completedTaskIds.includes(t.id));

        if (pendingTasks.length === 0) {
            logger.info(`[${shortEmail}] All tasks already completed`);

            // Mark as fully completed
            updateAccountData(email, {
                tasksCompleted: true,
                earnBalance,
                xpBalance,
                lastTasksRun: new Date().toISOString(),
            });

            return { success: true, completed: 0, total: allTasks.length, skipped: true };
        }

        logger.info(`[${shortEmail}] Found ${pendingTasks.length} pending tasks`);

        let completedCount = 0;

        for (const task of pendingTasks) {
            try {
                // Add rewards
                earnBalance += parseFloat(task.reward_earn) || 0;
                xpBalance += parseInt(task.reward_xp) || 0;
                const newLevel = calculateLevel(xpBalance);

                // Update profile
                await withRetry(
                    () => api.updateProfile(accessToken, userId, {
                        earn_balance: earnBalance,
                        xp_balance: xpBalance,
                        level: newLevel,
                    }),
                    'Update profile',
                    logger,
                    shortEmail
                );
                await randomDelay(3000, 5000);

                // Create transaction
                await withRetry(
                    () => api.createTransaction(
                        accessToken,
                        userId,
                        'task_reward',
                        parseFloat(task.reward_earn) || 0,
                        `Completed: ${task.title}`
                    ),
                    'Create transaction',
                    logger,
                    shortEmail
                );
                await randomDelay(3000, 5000);

                // Mark task as completed (INSERT into user_tasks)
                try {
                    await withRetry(
                        () => api.markTaskCompleted(accessToken, userId, task.id),
                        'Mark complete',
                        logger,
                        shortEmail
                    );
                } catch (markError) {
                    logger.warn(`[${shortEmail}] Mark complete failed (balance updated): ${markError.message?.slice(0, 50)}`);
                }
                await randomDelay(3000, 5000);

                completedCount++;
                logger.success(`[${shortEmail}] Completed: ${task.title} (+${task.reward_earn} EARN)`);

            } catch (taskError) {
                const errMsg = (taskError.message || '').replace(/\n/g, ' ');
                logger.warn(`[${shortEmail}] Task "${task.title}" failed: ${errMsg}`);
            }
        }

        // Update account data
        const allCompleted = completedCount === pendingTasks.length;
        updateAccountData(email, {
            earnBalance,
            xpBalance,
            level: calculateLevel(xpBalance),
            tasksCompleted: allCompleted,
            lastTasksRun: new Date().toISOString(),
        });

        logger.info(`[${shortEmail}] Tasks done: ${completedCount}/${pendingTasks.length}, Total: ${earnBalance} EARN`);

        return {
            success: true,
            completed: completedCount,
            total: pendingTasks.length,
            earnBalance,
            xpBalance,
        };

    } catch (error) {
        const errMsg = (error.message || '').replace(/\n/g, ' ');
        logger.error(`[${shortEmail}] Tasks failed: ${errMsg}`);
        return { success: false, error: errMsg };
    }
}

export default completeTasks;
