/**
 * CWave Registration Bot - API Client
 */

import { gotScraping } from 'got-scraping';
import { generateUUID } from '../utils/helper.js';

// Hardcoded configuration
const SUPABASE_URL = 'https://qpzjnejmxtifajnkfuoh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwempuZWpteHRpZmFqbmtmdW9oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcyMjExOTMsImV4cCI6MjA4Mjc5NzE5M30.lVbiUI5_WIkI8mACai8V5fRdEzcXbJ8_z1L3Ar5ZulI';
const CRYPTOWAVE_BASE_URL = 'https://cryptowave.blog';
const CRYPTOWAVE_AUTH_URL = 'https://cryptowave.blog/auth';

/**
 * Extract browser info from UA string
 */
function extractBrowserInfo(ua) {
    const chromeMatch = ua.match(/Chrome\/(\d+)/);
    const chromeVer = chromeMatch ? chromeMatch[1] : '142';

    // Detect platform from UA
    let platform = '"Windows"';
    let mobile = '?0';

    if (ua.includes('Macintosh') || ua.includes('Mac OS')) {
        platform = '"macOS"';
    } else if (ua.includes('Linux') && !ua.includes('Android')) {
        platform = '"Linux"';
    } else if (ua.includes('Android')) {
        platform = '"Android"';
        mobile = '?1';
    }

    // Generate sec-ch-ua matching Chrome version
    const secChUa = `"Not/A)Brand";v="8", "Chromium";v="${chromeVer}", "Google Chrome";v="${chromeVer}"`;

    return { chromeVer, platform, mobile, secChUa };
}

/**
 * Create API client with optional proxy support
 * @param {string|null} proxyUrl - Proxy URL or null for direct connection
 * @param {string} userAgent - User agent string
 */
export function createApiClient(proxyUrl = null, userAgent = null) {
    const defaultUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36';
    const ua = userAgent || defaultUserAgent;
    const { chromeVer, platform, mobile, secChUa } = extractBrowserInfo(ua);

    const baseOptions = {
        timeout: { request: 150000 },
        retry: { limit: 0 },
        throwHttpErrors: false,
        ...(proxyUrl && { proxyUrl }),
    };

    const commonHeaders = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'dnt': '1',
        'pragma': 'no-cache',
        'priority': 'u=1, i',
        'sec-ch-ua': secChUa,
        'sec-ch-ua-mobile': mobile,
        'sec-ch-ua-platform': platform,
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-gpc': '1',
        'user-agent': ua,
    };

    const supabaseHeaders = {
        ...commonHeaders,
        'apikey': SUPABASE_ANON_KEY,
        'authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'origin': CRYPTOWAVE_BASE_URL,
        'referer': `${CRYPTOWAVE_BASE_URL}/`,
        'sec-fetch-site': 'cross-site',
        'x-client-info': 'supabase-js-web/2.89.0',
    };

    return {
        /**
         * Send analytics event
         * @param {string} sessionId - Session UUID
         * @param {string} refCode - Referral code
         */
        async sendAnalytics(sessionId, refCode) {
            const payload = {
                timestamp: new Date().toISOString(),
                action: 'page_hit',
                version: '1',
                session_id: sessionId,
                payload: JSON.stringify({
                    'user-agent': ua,
                    'locale': 'en-US',
                    'location': 'ID',
                    'referrer': '',
                    'pathname': '/auth',
                    'href': `${CRYPTOWAVE_AUTH_URL}?ref=${refCode}`,
                }),
            };

            const response = await gotScraping.post(`${CRYPTOWAVE_BASE_URL}/~api/analytics`, {
                ...baseOptions,
                headers: {
                    ...commonHeaders,
                    'content-type': 'application/json',
                    'origin': CRYPTOWAVE_BASE_URL,
                    'referer': `${CRYPTOWAVE_AUTH_URL}?ref=${refCode}`,
                    'sec-fetch-site': 'same-origin',
                    'priority': 'u=1, i',
                },
                json: payload,
            });

            if (response.statusCode >= 400) {
                throw new Error(`Analytics failed: ${response.statusCode}`);
            }

            return response.body;
        },

        /**
         * Signup with Supabase
         * @param {string} email - Email address
         * @param {string} password - Password
         * @param {string} displayName - Display name
         * @param {string} refCode - Referral code
         */
        async signup(email, password, displayName, refCode) {
            const payload = {
                email,
                password,
                data: {
                    display_name: displayName,
                    referral_code: refCode,
                },
                gotrue_meta_security: {},
                code_challenge: null,
                code_challenge_method: null,
            };

            const response = await gotScraping.post(
                `${SUPABASE_URL}/auth/v1/signup?redirect_to=${encodeURIComponent(CRYPTOWAVE_BASE_URL + '/')}`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'content-type': 'application/json;charset=UTF-8',
                        'x-supabase-api-version': '2024-01-01',
                    },
                    json: payload,
                    responseType: 'json',
                }
            );

            // Check for error responses
            if (response.statusCode >= 400) {
                const errorBody = response.body || {};
                // Supabase can return error in different fields
                const errorMsg = errorBody.error_description
                    || errorBody.message
                    || errorBody.msg
                    || errorBody.error
                    || JSON.stringify(errorBody)
                    || `HTTP ${response.statusCode}`;
                throw new Error(`Signup failed: ${errorMsg}`);
            }

            return response.body;
        },

        /**
         * Login with email/password to get fresh tokens
         * @param {string} email - Email address
         * @param {string} password - Password
         */
        async login(email, password) {
            const payload = {
                email,
                password,
                gotrue_meta_security: {},
            };

            const response = await gotScraping.post(
                `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'content-type': 'application/json;charset=UTF-8',
                        'x-supabase-api-version': '2024-01-01',
                    },
                    json: payload,
                    responseType: 'json',
                }
            );

            if (response.statusCode >= 400) {
                const errorBody = response.body || {};
                const errorMsg = errorBody.error_description
                    || errorBody.message
                    || errorBody.msg
                    || errorBody.error
                    || JSON.stringify(errorBody)
                    || `HTTP ${response.statusCode}`;
                throw new Error(`Login failed: ${errorMsg}`);
            }

            return response.body;
        },

        /**
         * Get profile info
         * @param {string} accessToken - Access token from signup
         * @param {string} userId - User ID
         */
        async getProfile(accessToken, userId) {
            const response = await gotScraping.get(
                `${SUPABASE_URL}/rest/v1/profiles?select=*&user_id=eq.${userId}`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'authorization': `Bearer ${accessToken}`,
                        'accept': 'application/json',
                        'accept-profile': 'public',
                    },
                    responseType: 'json',
                }
            );

            if (response.statusCode >= 400) {
                throw new Error(`Get profile failed: ${response.statusCode}`);
            }

            return response.body?.[0] || null;
        },

        /**
         * Get active social tasks
         * @param {string} accessToken - Access token
         */
        async getTasks(accessToken) {
            const response = await gotScraping.get(
                `${SUPABASE_URL}/rest/v1/social_tasks?select=*&is_active=eq.true`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'authorization': `Bearer ${accessToken}`,
                        'accept-profile': 'public',
                    },
                    responseType: 'json',
                }
            );

            if (response.statusCode >= 400) {
                throw new Error(`Get tasks failed: ${response.statusCode}`);
            }

            return response.body || [];
        },

        /**
         * Get user completed tasks
         * @param {string} accessToken - Access token
         * @param {string} userId - User ID
         */
        async getCompletedTasks(accessToken, userId) {
            const response = await gotScraping.get(
                `${SUPABASE_URL}/rest/v1/user_tasks?select=task_id&user_id=eq.${userId}`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'authorization': `Bearer ${accessToken}`,
                        'accept-profile': 'public',
                    },
                    responseType: 'json',
                }
            );

            if (response.statusCode >= 400) {
                throw new Error(`Get completed tasks failed: ${response.statusCode}`);
            }

            return (response.body || []).map(t => t.task_id);
        },

        /**
         * Update profile balance
         * @param {string} accessToken - Access token
         * @param {string} userId - User ID
         * @param {object} data - { earn_balance, xp_balance, level }
         */
        async updateProfile(accessToken, userId, data) {
            const response = await gotScraping.patch(
                `${SUPABASE_URL}/rest/v1/profiles?user_id=eq.${userId}`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'authorization': `Bearer ${accessToken}`,
                        'content-profile': 'public',
                        'content-type': 'application/json',
                    },
                    json: data,
                }
            );

            if (response.statusCode >= 400) {
                throw new Error(`Update profile failed: ${response.statusCode}`);
            }
        },

        /**
         * Create transaction record
         * @param {string} accessToken - Access token
         * @param {string} userId - User ID
         * @param {string} type - Transaction type
         * @param {number} amount - Amount
         * @param {string} description - Description
         */
        async createTransaction(accessToken, userId, type, amount, description) {
            const response = await gotScraping.post(
                `${SUPABASE_URL}/rest/v1/transactions`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'authorization': `Bearer ${accessToken}`,
                        'content-profile': 'public',
                        'content-type': 'application/json',
                    },
                    json: {
                        user_id: userId,
                        type,
                        amount,
                        description,
                    },
                }
            );

            if (response.statusCode >= 400) {
                throw new Error(`Create transaction failed: ${response.statusCode}`);
            }
        },

        /**
         * Mark task as completed (INSERT into user_tasks)
         * @param {string} accessToken - Access token
         * @param {string} userId - User ID
         * @param {string} taskId - Task ID
         */
        async markTaskCompleted(accessToken, userId, taskId) {
            const response = await gotScraping.post(
                `${SUPABASE_URL}/rest/v1/user_tasks`,
                {
                    ...baseOptions,
                    headers: {
                        ...supabaseHeaders,
                        'authorization': `Bearer ${accessToken}`,
                        'content-profile': 'public',
                        'content-type': 'application/json',
                    },
                    json: {
                        user_id: userId,
                        task_id: taskId,
                    },
                }
            );

            if (response.statusCode >= 400) {
                throw new Error(`Mark task completed failed: ${response.statusCode}`);
            }
        },
    };
}

export default createApiClient;
