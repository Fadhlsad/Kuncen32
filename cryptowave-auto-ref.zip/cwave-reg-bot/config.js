/**
 * CWave Registration Bot - Configuration
 */

// Referral codes - randomly selected during registration
export const REF_CODES = [
    'EARN7BCD3B',
    // Add more referral codes here
];

export default {
    REF_CODES,
};
